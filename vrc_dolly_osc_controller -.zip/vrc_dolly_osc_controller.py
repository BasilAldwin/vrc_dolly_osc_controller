# -*- coding: utf-8 -*-
# --- Addon Information ---
bl_info = {
    "name": "VRChat Blender Dolly Link",
    "author": "User & AI",
    "version": (1, 6, 1), # Removed deprecated 'depress' attribute
    "blender": (4, 0, 0),
    "location": "Properties > Scene Properties > VRC Blender Dolly Link",
    "description": "Exports Blender Camera animation, sends to VRChat Camera Dolly via OSC. Includes adjustable Live Preview and optional Y/Z Rotation swap.",
    "warning": "Requires 'python-osc' library. VRChat OSC must be enabled. Very low Live Preview Intervals can cause instability.",
    "doc_url": "",
    "category": "Scene",
}

# --- Imports ---
import bpy
import sys
import os
import traceback
import json
import math
from mathutils import Vector, Euler, Matrix, Quaternion
import time

# --- Attempt to import bundled python-osc library ---
addon_dir = os.path.dirname(__file__)
libs_dir = os.path.join(addon_dir, "libs")
PYTHONOSC_AVAILABLE = False
if libs_dir not in sys.path: sys.path.append(libs_dir)
try:
    from pythonosc import udp_client, osc_message_builder
    PYTHONOSC_AVAILABLE = True
    print("[VRC Blender Dolly Link] python-osc library loaded.")
except ImportError:
    print("[VRC Blender Dolly Link ERROR] Failed to import python-osc. Ensure it's in the 'libs' folder.")
    class udp_client: SimpleUDPClient = lambda *args, **kwargs: None # type: ignore
    class osc_message_builder: # type: ignore
        OscMessageBuilder = lambda *args, **kwargs: None
        def add_arg(*args, **kwargs): pass
        def build(*args, **kwargs): return None

# --- Constants ---
DEFAULT_VRC_IP = "127.0.0.1"
DEFAULT_VRC_OSC_PORT = 9000
# Define the axis correction rotation: -90 degrees around World X-axis
AXIS_CORRECTION_QUAT_NEG90X = Quaternion((1.0, 0.0, 0.0), math.radians(-90.0))
# Identity Quaternion (no rotation)
QUAT_IDENTITY = Quaternion((1.0, 0.0, 0.0, 0.0))

# --- Addon Properties ---
class VRCDollyLinkSettings(bpy.types.PropertyGroup):
    camera_object: bpy.props.PointerProperty( name="Source Camera", type=bpy.types.Object, poll=lambda self, obj: obj.type == 'CAMERA' )
    target_ip: bpy.props.StringProperty( name="VRChat IP", default=DEFAULT_VRC_IP )
    target_port: bpy.props.IntProperty( name="VRChat OSC Port", default=DEFAULT_VRC_OSC_PORT, min=1, max=65535 )
    is_sending_active: bpy.props.BoolProperty( name="Enable OSC Sending", default=False, description="Master switch for enabling OSC communication" )
    is_live_preview_active: bpy.props.BoolProperty( name="Live Preview Active", default=False, description="Indicates if Live Preview mode is running", options={'SKIP_SAVE'}) # Don't save live state

    # --- Live Preview Setting ---
    live_preview_interval: bpy.props.FloatProperty(
        name="Live Preview Interval (s)", default=0.15, min=0.05, max=2.0, precision=2, step=5, # Step is 100*value
        description="Time between updates during Live Preview. Lower values increase responsiveness but may cause instability (<0.1 recommended only for testing)"
    )

    # --- Export Settings ---
    path_relative_to_dolly_start: bpy.props.BoolProperty(
        name="Path Relative to Dolly Start Pos (IsLocal=True)", default=True,
        description="Check this to make path start relative to the VRChat Dolly Track object (Requires Stationary Dolly Track in VRChat)"
    )
    apply_axis_correction: bpy.props.BoolProperty(
        name="Apply Axis Correction (-90° X Rot)", default=True,
        description="Apply standard Blender World -> VRC/Unity World axis rotation correction. Disable if orientation seems flipped/incorrect."
    )
    # Rotation Swap Option
    swap_yz_rotation: bpy.props.BoolProperty(
        name="Swap Output Y/Z Rotation", default=False,
        description="Manually swap the final Y and Z rotation values sent to VRChat. Use if rotation feels incorrect around those axes."
    )
    include_start_end_frames: bpy.props.BoolProperty( name="Include Scene Start/End Frames", default=True )
    calculate_speed: bpy.props.BoolProperty( name="Calculate Speed from Keyframes", default=True )
    default_speed: bpy.props.FloatProperty( name="Default Speed (Units/sec)", default=3.0, min=0.1, max=15.0 ) # Clamp max to VRC limit
    point_wait_time: bpy.props.FloatProperty( name="Wait Time At Point (sec)", default=0.0, min=0.0, max=60.0, precision=2 )
    override_zoom: bpy.props.BoolProperty(name="Override Zoom (FOV)", default=False)
    default_zoom: bpy.props.FloatProperty( name="Zoom (FOV)", default=45.0, min=20.0, max=150.0 )
    override_dof: bpy.props.BoolProperty(name="Override DOF Settings", default=False)
    default_focal_distance: bpy.props.FloatProperty( name="Focal Distance", default=1.5, min=0.0, max=10.0 )
    default_aperture: bpy.props.FloatProperty( name="Aperture (f-stop)", default=15.0, min=1.4, max=32.0 )
    status_message: bpy.props.StringProperty(name="Status", default="Ready", options={'SKIP_SAVE'})


# --- Helper Function to Send OSC ---
def send_osc_message(settings, address, args=None):
    if not settings or not settings.is_sending_active: return False
    if not PYTHONOSC_AVAILABLE: print("[VRC Link Error] OSC Lib missing."); settings.status_message = "Error: python-osc missing!"; return False
    ip = settings.target_ip; port = settings.target_port
    try:
        client = udp_client.SimpleUDPClient(ip, port)
        builder = osc_message_builder.OscMessageBuilder(address=address)
        if args is not None:
            if not isinstance(args, (list, tuple)): args = [args]
            for arg in args:
                if isinstance(arg, bool): builder.add_arg(arg, arg_type='T' if arg else 'F')
                elif isinstance(arg, int): builder.add_arg(arg, arg_type='i')
                elif isinstance(arg, float): builder.add_arg(arg, arg_type='f')
                elif isinstance(arg, str): builder.add_arg(arg, arg_type='s')
                else: print(f"[VRC Link Warning] OSC Send: Unknown arg type {type(arg)}, sending as default."); builder.add_arg(arg)
        msg = builder.build()
        client.send(msg)
        return True
    except ConnectionRefusedError: print(f"[VRC Link Error] OSC Connection Refused to {ip}:{port}. Is VRChat running & OSC enabled?"); settings.status_message = "Error: Connection Refused!"; return False
    except OSError as e: print(f"[VRC Link Error] OSC Network Error to {ip}:{port}: {e}"); settings.status_message = f"Error: Network Error ({e.errno})!"; return False
    except Exception as e: print(f"[VRC Link Error] OSC Send Fail to {ip}:{port} | {address}: {e}"); settings.status_message = f"Error: OSC Send Fail! Check Console."; return False

# --- Core Logic: Export Blender Anim to VRC JSON String ---
def generate_vrc_json_from_blender_cam(context, cam_object, settings):
    scene = context.scene
    if not cam_object or cam_object.type != 'CAMERA': return None, "No valid Camera selected."

    # --- Get Frames ---
    keyframe_frames = set()
    if cam_object.animation_data and cam_object.animation_data.action:
        action = cam_object.animation_data.action
        for fcurve in action.fcurves:
            if fcurve.data_path in ("location", "rotation_euler", "rotation_quaternion", "scale"):
                if fcurve.array_index >= 0 and fcurve.array_index <= 3:
                    for kp in fcurve.keyframe_points: keyframe_frames.add(int(round(kp.co.x)))
    frames_to_export = set(keyframe_frames)
    if settings.include_start_end_frames:
        frames_to_export.add(scene.frame_start); frames_to_export.add(scene.frame_end)
    if not frames_to_export:
        frames_to_export.add(scene.frame_start)
        if scene.frame_start != scene.frame_end: frames_to_export.add(scene.frame_end)
    sorted_frames = sorted(list(frames_to_export))
    if not sorted_frames: return None, "No frames to export."

    # --- Process Frames ---
    vrc_path_data = []; original_frame = scene.frame_current; prev_frame_data = None
    fps = scene.render.fps / scene.render.fps_base
    if fps <= 0: fps = 30.0

    try:
        for index, frame in enumerate(sorted_frames):
            if settings.include_start_end_frames and (frame < scene.frame_start or frame > scene.frame_end):
                 if not keyframe_frames and frame in (scene.frame_start, scene.frame_end): pass
                 elif frame in keyframe_frames and frame in (scene.frame_start, scene.frame_end): pass
                 else: continue

            scene.frame_set(frame);
            context.view_layer.update()
            world_matrix = cam_object.matrix_world
            b_pos = world_matrix.translation; b_quat = world_matrix.to_quaternion(); b_cam_data = cam_object.data

            # --- VRChat Coordinate Conversion ---
            # 1. Position: B(X,Y,Z) -> V(X,Z,Y)
            vrc_pos = {"X": b_pos.x, "Y": b_pos.z, "Z": b_pos.y}

            # 2. Rotation: Standard conversion
            world_correction = AXIS_CORRECTION_QUAT_NEG90X if settings.apply_axis_correction else QUAT_IDENTITY
            corrected_b_quat = world_correction @ b_quat
            vrc_quat_components = Quaternion((-corrected_b_quat.w, corrected_b_quat.x, corrected_b_quat.z, corrected_b_quat.y))
            try: vrc_rot_rad = vrc_quat_components.to_euler('YXZ')
            except ValueError: print(f"[VRC Link Warning] Euler conversion failed frame {frame}. Using zero."); vrc_rot_rad = Euler((0.0, 0.0, 0.0), 'YXZ')

            # Optional Y/Z Euler Value Swap
            final_rot_rad_y = vrc_rot_rad.y
            final_rot_rad_z = vrc_rot_rad.z
            if settings.swap_yz_rotation:
                final_rot_rad_y = vrc_rot_rad.z
                final_rot_rad_z = vrc_rot_rad.y
            vrc_rot_deg = {"X": math.degrees(vrc_rot_rad.x), "Y": math.degrees(final_rot_rad_y), "Z": math.degrees(final_rot_rad_z)}

            # --- VRChat Camera Settings (Zoom/FOV, DOF) ---
            sensor_fit = b_cam_data.sensor_fit; sensor_width = b_cam_data.sensor_width; sensor_height = b_cam_data.sensor_height
            aspect_ratio = sensor_width / sensor_height if sensor_height != 0 else 1.0
            h_fov_rad = b_cam_data.angle
            if sensor_fit == 'HORIZONTAL' or sensor_fit == 'AUTO': v_fov_rad = 2 * math.atan(math.tan(h_fov_rad / 2) / aspect_ratio) if aspect_ratio > 0.001 else h_fov_rad
            elif sensor_fit == 'VERTICAL': v_fov_rad = h_fov_rad
            else: v_fov_rad = h_fov_rad
            zoom = settings.default_zoom if settings.override_zoom else math.degrees(v_fov_rad)
            zoom = max(20.0, min(zoom, 150.0))

            focal_dist = settings.default_focal_distance; aperture = settings.default_aperture
            if not settings.override_dof and b_cam_data.dof.use_dof:
                if b_cam_data.dof.focus_object:
                    try:
                        depsgraph = context.evaluated_depsgraph_get(); cam_eval = cam_object.evaluated_get(depsgraph)
                        focus_obj_eval = b_cam_data.dof.focus_object.evaluated_get(depsgraph)
                        focal_dist = (cam_eval.matrix_world.translation - focus_obj_eval.matrix_world.translation).length
                    except: focal_dist = b_cam_data.dof.focus_distance
                else: focal_dist = b_cam_data.dof.focus_distance
                aperture = b_cam_data.dof.aperture_fstop
                focal_dist = max(0.0, min(focal_dist, 10.0)); aperture = max(1.4, min(aperture, 32.0))

            # --- Speed & Duration ---
            speed = settings.default_speed; duration = settings.point_wait_time
            if settings.calculate_speed and prev_frame_data and frame > prev_frame_data["frame"]:
                delta_time = (frame - prev_frame_data["frame"]) / fps
                if delta_time > 0.001:
                    prev_vrc_vec = Vector((prev_frame_data["vrc_pos"]["X"], prev_frame_data["vrc_pos"]["Y"], prev_frame_data["vrc_pos"]["Z"]))
                    curr_vrc_vec = Vector((vrc_pos["X"], vrc_pos["Y"], vrc_pos["Z"]))
                    distance = (curr_vrc_vec - prev_vrc_vec).length
                    calculated_speed = distance / delta_time
                    speed = max(0.1, min(calculated_speed, 15.0))

            # --- Assemble Point ---
            point = {
                "Position": {k: round(v, 4) for k, v in vrc_pos.items()}, "Rotation": {k: round(v, 4) for k, v in vrc_rot_deg.items()},
                "Zoom": round(zoom, 4), "FocalDistance": round(focal_dist, 4), "Aperture": round(aperture, 4),
                "Speed": round(speed, 4), "Duration": round(duration, 4), "IsLocal": settings.path_relative_to_dolly_start,
                "Index": -1, "PathIndex": 0, "Hue": 120.0, "Saturation": 100.0, "Lightness": 50.0,
                "LookAtMeXOffset": 0.0, "LookAtMeYOffset": 0.0,
            }
            vrc_path_data.append(point)
            prev_frame_data = {"frame": frame, "vrc_pos": vrc_pos}
    except Exception as e: settings.status_message = "Error during export processing!"; print(f"\n[VRC Link Error] Export processing error: {e}"); traceback.print_exc(); return None, f"Processing error: {e}"
    finally: scene.frame_set(original_frame); context.view_layer.update()

    # --- Convert to JSON String ---
    if not vrc_path_data: return None, "No path points generated."
    try:
        if len(vrc_path_data) < 2 and len(sorted_frames) < 2:
             if vrc_path_data: vrc_path_data.append(vrc_path_data[0].copy())
             else: return None, "Cannot create path with zero points."
        json_string = json.dumps(vrc_path_data, indent=None, separators=(',', ':'))
        return json_string, f"Generated JSON ({len(vrc_path_data)} points)."
    except Exception as e: settings.status_message = "Error generating JSON!"; print(f"\n[VRC Link Error] JSON generation error: {e}"); traceback.print_exc(); return None, f"JSON generation error: {e}"

# --- Helper for Export and Play Sequence ---
def _export_and_play_sequence(context):
    settings = context.scene.vrc_dolly_link_settings; cam_object = settings.camera_object
    if not settings.is_sending_active: settings.status_message = "Enable OSC Sending first!"; return False
    if not cam_object: settings.status_message = "Error: No Source Camera selected."; return False
    if not PYTHONOSC_AVAILABLE: settings.status_message = "Error: python-osc missing!"; return False
    json_data_string, message = generate_vrc_json_from_blender_cam(context, cam_object, settings)
    if json_data_string is None: settings.status_message = f"Error: {message}"; print(f"[VRC Link Error] Live Preview: Failed to generate JSON: {message}"); return False
    import_success = send_osc_message(settings, "/dolly/Import", json_data_string)
    if not import_success: settings.status_message = "OSC /dolly/Import FAILED."; print("[VRC Link Error] Live Preview: OSC /dolly/Import FAILED."); return False
    play_success = send_osc_message(settings, "/dolly/Play", True)
    if play_success: settings.status_message = f"Live: Sent ({len(json.loads(json_data_string)) if json_data_string else 0} pts)"
    else: settings.status_message = "OSC /dolly/Play FAILED."; print("[VRC Link Error] Live Preview: OSC /dolly/Play FAILED."); return False
    return True

# --- Operators ---
class SCENE_OT_vrc_link_export_send(bpy.types.Operator):
    bl_idname = "scene.vrc_link_export_send"; bl_label = "Export and Send Path Once"; bl_options = {'REGISTER', 'UNDO'}
    @classmethod
    def poll(cls, context):
        try: settings = context.scene.vrc_dolly_link_settings; return PYTHONOSC_AVAILABLE and settings.is_sending_active and settings.camera_object is not None
        except AttributeError: return False
    def execute(self, context):
        settings = context.scene.vrc_dolly_link_settings; cam_object = settings.camera_object
        if not cam_object: settings.status_message = "Error: No Source Camera selected."; self.report({'ERROR'}, "No Source Camera selected."); return {'CANCELLED'}
        if not settings.is_sending_active: settings.status_message = "Error: OSC Sending disabled."; self.report({'ERROR'}, "OSC Sending disabled."); return {'CANCELLED'}
        settings.status_message = "Generating JSON..."
        json_data_string, message = generate_vrc_json_from_blender_cam(context, cam_object, settings)
        if json_data_string is None: settings.status_message = f"Error: {message}"; self.report({'ERROR'}, f"Failed to generate JSON: {message}"); return {'CANCELLED'}
        settings.status_message = f"{message} Sending OSC..."
        success = send_osc_message(settings, "/dolly/Import", json_data_string)
        if success: settings.status_message = f"OSC /dolly/Import sent!"; self.report({'INFO'}, "OSC /dolly/Import command sent.")
        else: settings.status_message = f"OSC /dolly/Import FAILED."; self.report({'ERROR'}, "Failed to send OSC /dolly/Import.")
        return {'FINISHED'}

class SCENE_OT_vrc_link_play(bpy.types.Operator):
    bl_idname = "scene.vrc_link_play"; bl_label = "Play Last Sent Path"; bl_options = {'REGISTER', 'UNDO'}
    @classmethod
    def poll(cls, context):
        try: settings = context.scene.vrc_dolly_link_settings; return PYTHONOSC_AVAILABLE and settings.is_sending_active
        except AttributeError: return False
    def execute(self, context):
        settings = context.scene.vrc_dolly_link_settings
        if not settings.is_sending_active: settings.status_message = "Error: OSC Sending disabled."; self.report({'ERROR'}, "OSC Sending disabled."); return {'CANCELLED'}
        success = send_osc_message(settings, "/dolly/Play", True)
        settings.status_message = "Sent PLAY command." if success else "PLAY command failed!";
        if not success: self.report({'ERROR'}, "Failed to send OSC PLAY.")
        return {'FINISHED'}

class SCENE_OT_vrc_link_stop(bpy.types.Operator):
    bl_idname = "scene.vrc_link_stop"; bl_label = "Stop VRC Dolly"; bl_options = {'REGISTER', 'UNDO'}
    @classmethod
    def poll(cls, context):
        try: settings = context.scene.vrc_dolly_link_settings; return PYTHONOSC_AVAILABLE and settings.is_sending_active
        except AttributeError: return False
    def execute(self, context):
        settings = context.scene.vrc_dolly_link_settings
        if not settings.is_sending_active: settings.status_message = "Error: OSC Sending disabled."; self.report({'ERROR'}, "OSC Sending disabled."); return {'CANCELLED'}
        if settings.is_live_preview_active: settings.is_live_preview_active = False; print("[VRC Link] Stopping Live Preview via Stop button.")
        success = send_osc_message(settings, "/dolly/Play", False)
        settings.status_message = "Sent STOP command." if success else "STOP command failed!";
        if not success: self.report({'ERROR'}, "Failed to send OSC STOP.")
        return {'FINISHED'}

class SCENE_OT_vrc_link_live_preview(bpy.types.Operator):
    """Continuously exports and plays the camera path in VRChat via OSC"""
    bl_idname = "scene.vrc_link_live_preview"; bl_label = "Start/Stop Live Preview"; bl_options = {'REGISTER'}
    _timer = None; _last_update_time = 0.0
    @classmethod
    def poll(cls, context):
        try: settings = context.scene.vrc_dolly_link_settings; return PYTHONOSC_AVAILABLE
        except AttributeError: return False
    def invoke(self, context, event):
        settings = context.scene.vrc_dolly_link_settings
        if settings.is_live_preview_active:
            self._stop_modal(context); self.report({'INFO'}, "Live Preview Stopped"); return {'FINISHED'}
        else:
            if not settings.is_sending_active: settings.status_message = "Enable OSC Sending first!"; self.report({'ERROR'}, "Enable OSC Sending first!"); return {'CANCELLED'}
            if not settings.camera_object: settings.status_message = "Select Source Camera first!"; self.report({'ERROR'}, "Select Source Camera first!"); return {'CANCELLED'}
            if not PYTHONOSC_AVAILABLE: settings.status_message = "Error: python-osc missing!"; self.report({'ERROR'}, "python-osc library missing!"); return {'CANCELLED'}
            settings.is_live_preview_active = True; settings.status_message = "Live Preview Starting..."
            print("[VRC Link] Starting Live Preview...")
            success = _export_and_play_sequence(context)
            if not success: settings.status_message += " Failed Initial Send!"; print("[VRC Link Error] Live Preview: Initial send failed."); settings.is_live_preview_active = False; return {'CANCELLED'}
            wm = context.window_manager; interval = max(0.05, settings.live_preview_interval); self._timer = wm.event_timer_add(interval, window=context.window); wm.modal_handler_add(self)
            self._last_update_time = time.time(); settings.status_message = "Live Preview Active (ESC to Stop)"
            self.report({'INFO'}, f"Live Preview Started (Interval: {interval:.2f}s). Press ESC to stop.")
            return {'RUNNING_MODAL'}
    def modal(self, context, event):
        settings = context.scene.vrc_dolly_link_settings
        if not settings.is_live_preview_active or event.type == 'ESC' or not settings.is_sending_active or not settings.camera_object:
            if event.type == 'ESC': self.report({'INFO'}, "Live Preview Stopped (ESC)")
            elif not settings.is_live_preview_active: pass
            else: self.report({'WARNING'}, "OSC/Camera changed - Live Preview Stopped")
            return self._stop_modal(context)
        if event.type == 'TIMER':
            current_time = time.time(); interval = max(0.05, settings.live_preview_interval)
            if current_time - self._last_update_time >= interval * 0.9:
                 _export_and_play_sequence(context); self._last_update_time = current_time
        return {'PASS_THROUGH'}
    def _stop_modal(self, context):
        settings = context.scene.vrc_dolly_link_settings
        if self._timer: wm = context.window_manager; wm.event_timer_remove(self._timer); self._timer = None; print("[VRC Link] Live Preview timer removed.")
        if settings.is_live_preview_active: settings.is_live_preview_active = False;
        if settings.status_message.startswith("Live") or settings.status_message.startswith("OSC"): settings.status_message = "Live Preview Stopped."
        return {'FINISHED'}
    def cancel(self, context): print("[VRC Link Debug] Live Preview Operator Cancelled."); self._stop_modal(context)

# --- Panel Class (Corrected Draw Method - No 'depress') ---
class SCENE_PT_vrc_blender_dolly_link(bpy.types.Panel):
    bl_label = "VRC Blender Dolly Link"; bl_idname = "SCENE_PT_vrc_blender_dolly_link"
    bl_space_type = 'PROPERTIES'; bl_region_type = 'WINDOW'; bl_context = "scene"

    def draw_header(self, context): self.layout.label(text="", icon='CAMERA_DATA')
    def draw(self, context):
        layout = self.layout
        try: settings = context.scene.vrc_dolly_link_settings
        except AttributeError: layout.label(text="Error: Addon settings failed!", icon='ERROR'); return

        if not PYTHONOSC_AVAILABLE:
            box = layout.box(); box.alert = True; col = box.column(align=True)
            col.label(text="Required library 'python-osc' not found!", icon='ERROR')
            col.label(text="Place 'pythonosc' folder in addon's 'libs' folder & restart Blender.")
            return

        # --- Top Status/Enable Row ---
        row_status = layout.row(align=True)
        row_status.prop(settings, "is_sending_active", text="Enable OSC", toggle=True, icon='RADIOBUT_ON' if settings.is_sending_active else 'RADIOBUT_OFF')
        row_status.label(text=f"Status: {settings.status_message}", icon='INFO')
        layout.separator()

        # --- Configuration Section ---
        main_col = layout.column()
        box_config = main_col.box(); col_config = box_config.column(align=True)
        col_config.label(text="1. Select Source Camera:"); col_config.prop(settings, "camera_object", text="")
        col_config.separator()
        col_config.label(text="2. Configure OSC Target (VRChat):")
        row_target = col_config.row(align=True); row_target.prop(settings, "target_ip", text="IP"); row_target.prop(settings, "target_port", text="Port")
        col_config.separator()

        col_config.label(text="3. Configure Path Export Settings:")
        sub_box_export = col_config.box(); sub_col_export = sub_box_export.column(align=True)
        sub_col_export.enabled = settings.is_sending_active and settings.camera_object is not None
        sub_col_export.prop(settings, "path_relative_to_dolly_start")
        note_box = sub_col_export.box(); note_box.label(text="If Relative: Place VRC_DollyTrack object stationary BEFORE playing.", icon='INFO')
        sub_col_export.prop(settings, "apply_axis_correction")
        sub_col_export.prop(settings, "swap_yz_rotation") # Y/Z Swap Toggle
        sub_col_export.separator()
        sub_col_export.prop(settings, "include_start_end_frames")
        sub_col_export.prop(settings, "calculate_speed")
        row_def_speed = sub_col_export.row(align=True); row_def_speed.prop(settings, "default_speed"); row_def_speed.enabled = not settings.calculate_speed
        sub_col_export.prop(settings, "point_wait_time", text="Wait Time At Point (sec)")
        row_zoom = sub_col_export.row(align=True); row_zoom.prop(settings, "override_zoom", text="Override"); row_zoom.prop(settings, "default_zoom", text="Zoom (FOV)")
        row_zoom.split().column().enabled = settings.override_zoom
        row_dof = sub_col_export.row(align=True); row_dof.prop(settings, "override_dof", text="Override");
        sub_dof_col = row_dof.column(align=True); sub_dof_col.prop(settings, "default_focal_distance", text="Focal Dist"); sub_dof_col.prop(settings, "default_aperture", text="Aperture"); sub_dof_col.enabled = settings.override_dof

        # --- Live Preview Interval Setting ---
        col_config.separator()
        col_config.label(text="4. Live Preview Settings:")
        sub_box_live = col_config.box(); sub_col_live = sub_box_live.column(align=True)
        sub_col_live.enabled = settings.is_sending_active and settings.camera_object is not None
        sub_col_live.prop(settings, "live_preview_interval")


        # --- Action Section ---
        box_action = main_col.box(); col_action = box_action.column()
        col_action.label(text="5. Send / Control:")
        col_action.enabled = settings.is_sending_active and settings.camera_object is not None

        # --- Live Preview Button ---
        row_live = col_action.row(align=True)
        live_op = row_live.operator(SCENE_OT_vrc_link_live_preview.bl_idname,
                                    text="Live Preview" if not settings.is_live_preview_active else "Stop Live Preview",
                                    icon='PLAY' if not settings.is_live_preview_active else 'PAUSE')
        # 'depress' attribute removed here
        row_live.scale_y = 1.5

        col_action.separator()
        col_action.label(text="Manual Control:")

        # --- Standard Buttons ---
        row_export_send = col_action.row(); row_export_send.scale_y = 1.2;
        op_export = row_export_send.operator(SCENE_OT_vrc_link_export_send.bl_idname, icon='EXPORT', text="Export & Send Once")

        row_control = col_action.row(); row_control.scale_y = 1.2;
        op_play = row_control.operator(SCENE_OT_vrc_link_play.bl_idname, icon='PLAY', text="Play Last Sent")
        op_stop = row_control.operator(SCENE_OT_vrc_link_stop.bl_idname, icon='SNAP_VOLUME', text="Stop VRC Dolly")


# --- Registration ---
classes = (
    VRCDollyLinkSettings, SCENE_OT_vrc_link_export_send, SCENE_OT_vrc_link_play,
    SCENE_OT_vrc_link_stop, SCENE_OT_vrc_link_live_preview,
    SCENE_PT_vrc_blender_dolly_link
)
def register():
    print("-" * 40); print("[VRC Blender Dolly Link] Registering addon...")
    all_registered = True
    for cls in classes:
        try: bpy.utils.register_class(cls)
        except Exception as e: print(f"[VRC Link ERROR] Failed register {cls.__name__}: {e}"); all_registered = False
    if all_registered:
        try: bpy.types.Scene.vrc_dolly_link_settings = bpy.props.PointerProperty(type=VRCDollyLinkSettings)
        except Exception as e: print(f"[VRC Link ERROR] Failed register Scene prop: {e}"); all_registered = False
    if all_registered: print(f"[VRC Blender Dolly Link] Registration successful (v{bl_info['version'][0]}.{bl_info['version'][1]}.{bl_info['version'][2]}).")
    else: print("[VRC Blender Dolly Link ERROR] Registration failed.")
    print("-" * 40)

def unregister():
    print("-" * 40); print("[VRC Blender Dolly Link] Unregistering addon...")
    if bpy.context.window_manager and hasattr(bpy.context.scene, "vrc_dolly_link_settings"):
         settings = bpy.context.scene.vrc_dolly_link_settings
         if settings and settings.is_live_preview_active: settings.is_live_preview_active = False; print("[VRC Link] Signaling active Live Preview to stop during unregister.")
    if hasattr(bpy.types.Scene, "vrc_dolly_link_settings"):
        try: del bpy.types.Scene.vrc_dolly_link_settings
        except Exception: pass
    for cls in reversed(classes):
        if hasattr(bpy.utils, "unregister_class"):
             try: bpy.utils.unregister_class(cls)
             except RuntimeError: print(f"[VRC Link Warning] Could not unregister {cls.__name__} immediately.")
             except Exception as e: print(f"[VRC Link ERROR] Exception unregistering {cls.__name__}: {e}")
    if libs_dir in sys.path:
        try: sys.path.remove(libs_dir); print("[VRC Link] Removed libs directory from sys.path.")
        except ValueError: pass
    print("[VRC Blender Dolly Link] Unregistration finished.")
    print("-" * 40)

# --- End of Script ---